# XMedia Scanner V3.2 — stability pass

## Included
- Generic HTTP/HTTPS URL entry (no hardcoded host).
- Embedded Android WebView with JavaScript and DOM storage.
- Scan current page or follow detected next-page links up to 50 pages, restricted to the same host.
- Extract media URLs from image/source/video elements, srcset, anchors and CSS backgrounds.
- Two-column selectable media grid, select all / deselect all, batch download.
- Thumbnail decoding is sampled to reduce memory pressure on older phones.
- Downloads send WebView cookies for the source page and resource URL, plus Referer and User-Agent.
- HTTP errors and HTML/JSON responses are rejected rather than saved as fake image files.
- HLS/DASH playlists are identified as unsupported instead of being saved as broken videos.
- Saves to Pictures/XMediaScanner and Movies/XMediaScanner.

## Build
Open in Android Studio, install Android SDK 35, sync Gradle, then Build > Build Bundle(s) / APK(s) > Build APK(s).
APK output: app/build/outputs/apk/debug/app-debug.apk.

## Redmi K20 Pro test plan
1. Install debug APK on Android 12.
2. Open a public page and a page that requires sign-in (only if authorized).
3. Test current-page scan, then multi-page scan.
4. Scroll through the media grid; check thumbnails and selection.
5. Download one image, one MP4, then 5-10 selected files.
6. Confirm files appear in Pictures/XMediaScanner and Movies/XMediaScanner.
7. Test a site with pagination and a site using infinite scroll separately.

## Important
I cannot physically operate the user's Redmi K20 Pro from this environment, and this source has not been compiled or device-tested here. It is a source-code stability pass, not a verified production APK.
Pagination is heuristic. Infinite scroll, API-only content, blob URLs, DRM, signed URLs, protected attachments, HLS/DASH streams and nonstandard media endpoints may require site-specific handling. No authentication, paywall, CAPTCHA or access-control bypass is included. Use only media you are authorized to save.
