package com.example.xmediascanner

data class MediaItem(
    val url: String,
    val isVideo: Boolean,
    val sourcePage: String,
    var selected: Boolean = false
)
