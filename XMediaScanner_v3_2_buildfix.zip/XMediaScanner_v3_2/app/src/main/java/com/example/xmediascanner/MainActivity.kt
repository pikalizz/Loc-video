package com.example.xmediascanner

import android.app.Activity
import android.app.AlertDialog
import android.os.Bundle
import android.webkit.*
import android.widget.*
import android.view.View
import android.graphics.Color
import android.graphics.Typeface
import android.content.ContentValues
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import org.json.JSONObject
import org.json.JSONArray
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors

class MainActivity : Activity() {
    private lateinit var browser: WebView
    private lateinit var urlBox: EditText
    private lateinit var status: TextView
    private lateinit var browserPanel: LinearLayout
    private lateinit var mediaPanel: LinearLayout
    private lateinit var grid: GridView
    private lateinit var adapter: MediaAdapter

    private val items = mutableListOf<MediaItem>()
    private val mediaKeys = hashSetOf<String>()
    private val visitedPages = linkedSetOf<String>()
    private val pageQueue = ArrayDeque<String>()
    private val downloader = Executors.newFixedThreadPool(3)
    private var scanning = false
    private var maxPages = 50
    private var scannedPages = 0
    private var currentSourcePage = ""
    private var scanHost = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(8), dp(12), dp(8))
            setBackgroundColor(0xFF101827.toInt())
        }
        root.addView(TextView(this).apply {
            text = "XMEDIA SCANNER  V3.2"
            textSize = 19f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.WHITE)
            setPadding(2, 4, 0, 8)
        })
        urlBox = EditText(this).apply {
            setSingleLine(true)
            textSize = 13f
            setTextColor(Color.WHITE)
            setHintTextColor(0xFF9CA3AF.toInt())
            hint = "Nhập URL website bất kỳ"
            setPadding(dp(12), 0, dp(12), 0)
            background = rounded(0xFF263449.toInt(), 12)
        }
        root.addView(urlBox, LinearLayout.LayoutParams(-1, dp(46)))

        val nav = LinearLayout(this)
        button(nav, "MỞ", 0xFF34445D.toInt()) {
            val target = normalizeUrl(urlBox.text.toString())
            if (target != null) browser.loadUrl(target) else status.text = "URL không hợp lệ."
        }
        button(nav, "←", 0xFF34445D.toInt()) { if (browser.canGoBack()) browser.goBack() }
        button(nav, "QUÉT", 0xFF536DFE.toInt()) { chooseScanScope() }
        root.addView(nav)

        status = TextView(this).apply {
            text = "Nhập địa chỉ website bất kỳ, nhấn MỞ rồi QUÉT."
            textSize = 12f
            setTextColor(0xFFD1D5DB.toInt())
            setPadding(3, 7, 3, 7)
        }
        root.addView(status)

        browserPanel = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        browser = WebView(this).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.loadsImagesAutomatically = true
            settings.mediaPlaybackRequiresUserGesture = true
            settings.mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
            webViewClient = object : WebViewClient() {
                override fun onPageStarted(view: WebView?, url: String?, favicon: android.graphics.Bitmap?) {
                    if (!scanning) status.text = "Đang mở website…"
                }
                override fun onPageFinished(view: WebView?, url: String?) {
                    if (!scanning) {
                        url?.let { urlBox.setText(it) }
                        status.text = "Đã mở trang. Nhấn QUÉT để lấy media."
                    } else {
                        extractPage()
                    }
                }
                override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean = false
            }
            webChromeClient = WebChromeClient()
        }
        browserPanel.addView(browser, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(browserPanel, LinearLayout.LayoutParams(-1, 0, 1f))

        mediaPanel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            visibility = View.GONE
        }
        val actions = LinearLayout(this)
        button(actions, "CHỌN TẤT CẢ", 0xFF34445D.toInt()) { selectAll(true) }
        button(actions, "BỎ CHỌN", 0xFF34445D.toInt()) { selectAll(false) }
        button(actions, "TẢI ĐÃ CHỌN", 0xFF16865B.toInt()) { downloadSelected() }
        mediaPanel.addView(actions)
        grid = GridView(this).apply {
            numColumns = 2
            horizontalSpacing = dp(8)
            verticalSpacing = dp(8)
            stretchMode = GridView.STRETCH_COLUMN_WIDTH
        }
        adapter = MediaAdapter(items, ::requestHeaders) { updateSelectionStatus() }
        grid.adapter = adapter
        mediaPanel.addView(grid, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(mediaPanel, LinearLayout.LayoutParams(-1, 0, 1f))

        val tabs = LinearLayout(this)
        button(tabs, "TRÌNH DUYỆT", 0xFF34445D.toInt()) { showBrowser() }
        button(tabs, "KHO MEDIA", 0xFF536DFE.toInt()) { showMedia() }
        root.addView(tabs)
        setContentView(root)
    }

    private fun chooseScanScope() {
        val options = arrayOf("Chỉ quét trang đang mở", "Tự tìm trang kế tiếp (tối đa 50 trang)")
        AlertDialog.Builder(this).setTitle("Phạm vi quét")
            .setItems(options) { _, which ->
                maxPages = if (which == 0) 1 else 50
                startScan()
            }.setNegativeButton("Hủy", null).show()
    }

    private fun startScan() {
        val start = browser.url ?: normalizeUrl(urlBox.text.toString())
        if (start.isNullOrBlank()) {
            status.text = "Hãy mở website trước."
            return
        }
        val uri = Uri.parse(start)
        scanHost = uri.host ?: run { status.text = "Không xác định được tên miền."; return }
        items.clear()
        mediaKeys.clear()
        visitedPages.clear()
        pageQueue.clear()
        pageQueue.add(start)
        scannedPages = 0
        scanning = true
        showMedia()
        status.text = "Bắt đầu quét…"
        loadNextPage()
    }

    private fun loadNextPage() {
        if (!scanning) return
        while (pageQueue.isNotEmpty() && visitedPages.contains(pageQueue.first())) pageQueue.removeFirst()
        if (pageQueue.isEmpty() || scannedPages >= maxPages) {
            scanning = false
            status.text = "Hoàn tất: đã quét $scannedPages trang, tìm thấy ${items.size} media."
            adapter.notifyDataSetChanged()
            showMedia()
            return
        }
        val next = pageQueue.removeFirst()
        if (!sameHost(next, scanHost)) {
            loadNextPage()
            return
        }
        visitedPages.add(next)
        currentSourcePage = next
        browser.loadUrl(next)
    }

    private fun extractPage() {
        val js = """
        (function() {
          const media = new Set();
          const add = (u) => {
            if (!u || typeof u !== 'string' || /^(data:|blob:|javascript:)/i.test(u)) return;
            try { media.add(new URL(u, location.href).href); } catch(e) {}
          };
          document.querySelectorAll('img').forEach(e => {
            add(e.currentSrc); add(e.getAttribute('src')); add(e.getAttribute('data-src'));
            add(e.getAttribute('data-original')); add(e.getAttribute('data-lazy-src'));
            const ss=e.getAttribute('srcset'); if(ss) ss.split(',').forEach(x=>add(x.trim().split(/\s+/)[0]));
          });
          document.querySelectorAll('video, video source').forEach(e => { add(e.currentSrc); add(e.getAttribute('src')); });
          document.querySelectorAll('a[href]').forEach(e => add(e.href));
          document.querySelectorAll('[style*="background"]').forEach(e => {
            const s=e.getAttribute('style')||''; const re=/url\(['"]?(.*?)['"]?\)/ig; let m;
            while((m=re.exec(s))!==null) add(m[1]);
          });
          let next = '';
          const candidates = [
            document.querySelector('link[rel="next"]')?.href,
            document.querySelector('a[rel~="next"]')?.href,
            document.querySelector('a[aria-label*="Next" i]')?.href,
            document.querySelector('.pageNav-jump--next')?.href,
            document.querySelector('.pagination .next a')?.href,
            document.querySelector('a.next')?.href
          ].filter(Boolean);
          if(candidates.length) next=candidates[0];
          if(!next) {
            const links=[...document.querySelectorAll('a[href]')];
            const n=links.find(a => /^(next|older|›|»|tiếp|sau)$/i.test((a.textContent||'').trim()) ||
              /next|older|pageNav-jump--next/i.test((a.className||'')+' '+(a.getAttribute('rel')||'')));
            if(n) next=n.href;
          }
          return JSON.stringify({media:[...media], next:next, page:location.href});
        })();
        """.trimIndent()
        browser.evaluateJavascript(js) { raw ->
            try {
                val jsonText = org.json.JSONTokener(raw).nextValue() as? String ?: "{}"
                val obj = JSONObject(jsonText)
                val arr = obj.optJSONArray("media") ?: JSONArray()
                for (i in 0 until arr.length()) {
                    val u = arr.optString(i)
                    if (isMediaUrl(u) && mediaKeys.add(u)) {
                        items.add(MediaItem(u, isVideoUrl(u), currentSourcePage))
                    }
                }
                val next = obj.optString("next")
                if (maxPages > 1 && next.isNotBlank() && sameHost(next, scanHost) &&
                    !visitedPages.contains(next) && !pageQueue.contains(next)) pageQueue.add(next)
            } catch (_: Exception) { }
            scannedPages++
            adapter.notifyDataSetChanged()
            status.text = "Đang quét $scannedPages/$maxPages trang • ${items.size} media"
            loadNextPage()
        }
    }

    private fun isMediaUrl(url: String): Boolean {
        val uri = Uri.parse(url)
        val path = uri.path?.lowercase() ?: return false
        val ext = path.substringAfterLast('.', "")
        if (ext in setOf("jpg","jpeg","png","gif","webp","avif","bmp","mp4","webm","mov","m4v","m3u8","mpd")) return true
        val query = (uri.query ?: "").lowercase()
        val attachmentPath = path.contains("/attachments/") || path.contains("/attachment/")
        val mediaQuery = query.contains("type=image") || query.contains("type=video") ||
            query.contains("mime=image") || query.contains("mime=video")
        return attachmentPath && mediaQuery
    }
    private fun isVideoUrl(url: String): Boolean {
        val ext = Uri.parse(url).path?.substringAfterLast('.', "")?.lowercase()
        return ext in setOf("mp4","webm","mov","m4v","m3u8","mpd")
    }
    private fun sameHost(url: String, host: String) = Uri.parse(url).host.equals(host, true)

    private fun requestHeaders(referer: String, resourceUrl: String? = null): Map<String, String> {
        val manager = CookieManager.getInstance()
        val cookies = linkedSetOf<String>()
        manager.getCookie(referer)?.takeIf { it.isNotBlank() }?.let { cookies.add(it) }
        resourceUrl?.let { manager.getCookie(it)?.takeIf { c -> c.isNotBlank() }?.let { c -> cookies.add(c) } }
        val map = mutableMapOf(
            "User-Agent" to "Mozilla/5.0 (Linux; Android 12) AppleWebKit/537.36 Chrome/120 Mobile Safari/537.36",
            "Referer" to referer
        )
        if (cookies.isNotEmpty()) map["Cookie"] = cookies.joinToString("; ")
        return map
    }

    private fun downloadSelected() {
        val selected = items.filter { it.selected }
        if (selected.isEmpty()) {
            status.text = "Chưa chọn tệp nào."
            return
        }
        status.text = "Đang tải ${selected.size} tệp…"
        selected.forEach { item -> downloader.execute { downloadOne(item) } }
    }

    private fun downloadOne(item: MediaItem) {
        var outputUri: Uri? = null
        try {
            val conn = URL(item.url).openConnection() as HttpURLConnection
            requestHeaders(item.sourcePage, item.url).forEach { (k,v) -> conn.setRequestProperty(k,v) }
            conn.connectTimeout = 15000
            conn.readTimeout = 30000
            conn.instanceFollowRedirects = true
            val responseCode = conn.responseCode
            if (responseCode !in 200..299) error("Máy chủ trả HTTP $responseCode")
            val mimeFromServer = conn.contentType?.substringBefore(";")?.lowercase()
            if (mimeFromServer == "text/html" || mimeFromServer == "application/json") {
                error("Máy chủ trả trang HTML/JSON thay vì tệp media (có thể cần quyền truy cập)")
            }
            val streamExt = Uri.parse(item.url).path?.substringAfterLast('.', "")?.lowercase()
            if (streamExt == "m3u8" || streamExt == "mpd") {
                error("Video dạng HLS/DASH chưa hỗ trợ tải thành tệp đơn")
            }
            val pathName = Uri.parse(conn.url.toString()).lastPathSegment?.takeIf { it.contains(".") }
            val ext = pathName?.substringAfterLast('.')?.lowercase()
            val video = item.isVideo
            val name = (pathName ?: "xmedia_${System.currentTimeMillis()}.${if(video) "mp4" else "jpg"}")
                .replace(Regex("[^A-Za-z0-9._-]"), "_")
            val mime = mimeFromServer ?: when(ext) {
                "png" -> "image/png"; "gif" -> "image/gif"; "webp" -> "image/webp"
                "mp4" -> "video/mp4"; "webm" -> "video/webm"; else -> if(video) "video/*" else "image/jpeg"
            }
            val values = ContentValues().apply {
                put(MediaStore.MediaColumns.DISPLAY_NAME, name)
                put(MediaStore.MediaColumns.MIME_TYPE, mime)
                if (Build.VERSION.SDK_INT >= 29) put(MediaStore.MediaColumns.RELATIVE_PATH,
                    if(video) "Movies/XMediaScanner" else "Pictures/XMediaScanner")
            }
            val collection = if(video) MediaStore.Video.Media.EXTERNAL_CONTENT_URI else MediaStore.Images.Media.EXTERNAL_CONTENT_URI
            outputUri = contentResolver.insert(collection, values) ?: error("Không tạo được tệp đích")
            conn.inputStream.use { input ->
                contentResolver.openOutputStream(outputUri!!).use { output ->
                    requireNotNull(output) { "Không mở được tệp đích" }
                    input.copyTo(output)
                }
            }
            conn.disconnect()
            runOnUiThread { status.text = "Đã lưu $name" }
        } catch (e: Exception) {
            outputUri?.let { contentResolver.delete(it, null, null) }
            runOnUiThread { status.text = "Tải thất bại: ${e.message}" }
        }
    }

    private fun selectAll(value: Boolean) {
        items.forEach { it.selected = value }
        adapter.notifyDataSetChanged()
        updateSelectionStatus()
    }
    private fun updateSelectionStatus() {
        status.text = "${items.size} mục media • đã chọn ${items.count { it.selected }}"
    }
    private fun showBrowser() {
        browserPanel.visibility = View.VISIBLE
        mediaPanel.visibility = View.GONE
    }
    private fun showMedia() {
        browserPanel.visibility = View.GONE
        mediaPanel.visibility = View.VISIBLE
        adapter.notifyDataSetChanged()
    }
    private fun button(parent: LinearLayout, label: String, color: Int, action: () -> Unit) {
        val b = Button(this).apply {
            text = label; textSize = 10f; isAllCaps = false
            setTextColor(Color.WHITE); background = rounded(color, 12)
            setPadding(dp(3), 0, dp(3), 0); setOnClickListener { action() }
        }
        parent.addView(b, LinearLayout.LayoutParams(0, dp(44), 1f).apply {
            setMargins(dp(3), dp(5), dp(3), dp(5))
        })
    }
    private fun normalizeUrl(value: String): String? {
        val v = value.trim()
        if (v.isEmpty()) return null
        val fixed = if (v.startsWith("http://") || v.startsWith("https://")) v else "https://$v"
        val uri = Uri.parse(fixed)
        return if (!uri.host.isNullOrBlank() && (uri.scheme == "https" || uri.scheme == "http")) fixed else null
    }
    private fun rounded(color: Int, radius: Int) = android.graphics.drawable.GradientDrawable().apply {
        setColor(color); cornerRadius = dp(radius).toFloat()
    }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onDestroy() {
        browser.destroy()
        downloader.shutdown()
        super.onDestroy()
    }
}
