# Build APK chỉ bằng điện thoại Android

## Cách dùng GitHub Actions
1. Đăng nhập GitHub trên Chrome và tạo một repository mới (có thể để Private).
2. Giải nén ZIP mã nguồn này bằng ứng dụng quản lý tệp trên điện thoại.
3. Tải toàn bộ nội dung bên trong thư mục `XMediaScanner_v3_2` lên repository, giữ nguyên cấu trúc thư mục, bao gồm thư mục ẩn `.github`.
4. Mở repository trên GitHub → tab **Actions** → chọn workflow **Build XMedia Scanner APK** → **Run workflow** → **Run workflow**.
5. Chờ job chạy xong và hiện dấu tick xanh. Mở lần chạy đó, kéo xuống **Artifacts**, tải `XMedia-Scanner-debug-apk`.
6. Giải nén file artifact vừa tải. Cài `app-debug.apk` trên điện thoại; nếu Android hỏi, cho phép Chrome/trình quản lý tệp cài ứng dụng không rõ nguồn.

Nếu GitHub không nhận thư mục `.github` khi tải bằng giao diện web điện thoại, hãy dùng chức năng tải lên thư mục của trình duyệt ở chế độ Trang web cho máy tính, hoặc tạo file workflow theo đúng đường dẫn `.github/workflows/build-apk.yml`.

Đây là APK debug để cài thử, chưa phải bản phát hành ký số (release). Không chia sẻ APK từ nguồn không tin cậy.
