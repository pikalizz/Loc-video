package com.example.xmediascanner

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.util.LruCache
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import java.io.ByteArrayOutputStream
import java.lang.ref.WeakReference
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.CopyOnWriteArrayList
import java.util.concurrent.Executors

class MediaAdapter(
    private val items: MutableList<MediaItem>,
    private val headers: (String) -> Map<String, String>,
    private val selectionChanged: () -> Unit,
    private val preview: (MediaItem) -> Unit
) : BaseAdapter() {
    private val pool = Executors.newFixedThreadPool(5)
    private val main = Handler(Looper.getMainLooper())
    private val loading = ConcurrentHashMap.newKeySet<String>()
    private val visibleViews = ConcurrentHashMap<String, CopyOnWriteArrayList<WeakReference<ImageView>>>()
    private val cache = object : LruCache<String, Bitmap>(
        (Runtime.getRuntime().maxMemory() / 8 / 1024).toInt()
    ) {
        override fun sizeOf(key: String, value: Bitmap): Int = value.byteCount / 1024
    }

    override fun getCount() = items.size
    override fun getItem(position: Int) = items[position]
    override fun getItemId(position: Int) = items[position].url.hashCode().toLong()
    override fun hasStableIds() = true

    override fun getView(position: Int, recycled: View?, parent: ViewGroup): View {
        val holder: Holder
        val root: LinearLayout
        if (recycled == null) {
            root = LinearLayout(parent.context).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(3, 3, 3, 3)
                background = GradientDrawable().apply {
                    setColor(0xFF202C40.toInt())
                    cornerRadius = 12f
                }
            }
            val frame = FrameLayout(parent.context)
            val image = ImageView(parent.context).apply {
                scaleType = ImageView.ScaleType.CENTER_CROP
                setBackgroundColor(0xFF111827.toInt())
            }
            frame.addView(image, FrameLayout.LayoutParams(-1, dp(parent, 112)))
            val badge = TextView(parent.context).apply {
                text = "▶ VIDEO"
                textSize = 10f
                setTextColor(Color.WHITE)
                setPadding(7, 3, 7, 3)
                background = GradientDrawable().apply {
                    setColor(0xCC111827.toInt())
                    cornerRadius = 18f
                }
                visibility = View.GONE
            }
            frame.addView(badge, FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM or Gravity.START).apply {
                setMargins(5, 0, 0, 5)
            })
            val check = CheckBox(parent.context).apply {
                text = "Chọn"
                textSize = 11f
                setTextColor(Color.WHITE)
                setPadding(2, 0, 2, 0)
                minHeight = dp(parent, 32)
            }
            root.addView(frame)
            root.addView(check)
            holder = Holder(image, badge, check)
            root.tag = holder
        } else {
            root = recycled as LinearLayout
            holder = root.tag as Holder
        }

        val item = items[position]
        holder.check.setOnCheckedChangeListener(null)
        holder.check.isChecked = item.selected
        holder.check.setOnCheckedChangeListener { _, checked ->
            item.selected = checked
            selectionChanged()
        }
        holder.badge.visibility = if (item.isVideo) View.VISIBLE else View.GONE
        holder.image.tag = item.url

        if (item.isVideo) {
            holder.image.setImageDrawable(GradientDrawable().apply {
                setColor(0xFF34445D.toInt())
                cornerRadius = 10f
            })
        } else {
            val cached = cache.get(item.url)
            if (cached != null && !cached.isRecycled) {
                holder.image.setImageBitmap(cached)
            } else {
                holder.image.setImageDrawable(GradientDrawable().apply {
                    setColor(0xFF111827.toInt())
                    cornerRadius = 10f
                })
                visibleViews.getOrPut(item.url) { CopyOnWriteArrayList() }.add(WeakReference(holder.image))
                loadThumbnail(item)
            }
        }

        root.setOnClickListener { preview(item) }
        return root
    }

    private fun loadThumbnail(item: MediaItem) {
        if (!loading.add(item.url)) return
        pool.execute {
            try {
                // Tải dữ liệu đúng một lần; giải mã bounds và bitmap từ cùng bộ nhớ.
                val bytes = openImageConnection(item).use { input ->
                    val output = ByteArrayOutputStream(64 * 1024)
                    val buffer = ByteArray(16 * 1024)
                    var total = 0
                    while (true) {
                        val count = input.read(buffer)
                        if (count < 0) break
                        total += count
                        if (total > 25 * 1024 * 1024) throw java.io.IOException("Ảnh quá lớn")
                        output.write(buffer, 0, count)
                    }
                    output.toByteArray()
                }
                val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)
                if (bounds.outWidth > 0 && bounds.outHeight > 0) {
                    val sample = calculateSample(bounds.outWidth, bounds.outHeight, 480, 480)
                    val options = BitmapFactory.Options().apply {
                        inSampleSize = sample
                        inPreferredConfig = Bitmap.Config.RGB_565
                    }
                    val bitmap = BitmapFactory.decodeByteArray(bytes, 0, bytes.size, options)
                    if (bitmap != null) {
                        cache.put(item.url, bitmap)
                        main.post {
                            // Chỉ cập nhật các ô đang hiển thị, không refresh toàn bộ GridView.
                            visibleViews[item.url]?.removeAll { ref ->
                                val image = ref.get()
                                if (image == null) true else {
                                    if (image.tag == item.url) image.setImageBitmap(bitmap)
                                    false
                                }
                            }
                        }
                    }
                }
            } catch (_: Exception) {
                // Lỗi thumbnail không làm dừng quá trình quét hoặc tải tệp.
            } finally {
                loading.remove(item.url)
            }
        }
    }

    private fun openImageConnection(item: MediaItem): java.io.InputStream {
        val conn = URL(item.url).openConnection() as HttpURLConnection
        headers(item.sourcePage).forEach { (k, v) -> conn.setRequestProperty(k, v) }
        conn.setRequestProperty("Accept", "image/avif,image/webp,image/apng,image/*,*/*;q=0.8")
        conn.connectTimeout = 7000
        conn.readTimeout = 10000
        conn.useCaches = true
        conn.instanceFollowRedirects = true
        if (conn.responseCode !in 200..299) {
            val code = conn.responseCode
            conn.disconnect()
            throw java.io.IOException("HTTP $code")
        }
        return object : java.io.FilterInputStream(conn.inputStream) {
            override fun close() {
                try { super.close() } finally { conn.disconnect() }
            }
        }
    }

    private fun calculateSample(width: Int, height: Int, reqWidth: Int, reqHeight: Int): Int {
        var sample = 1
        var halfH = height / 2
        var halfW = width / 2
        while (halfH / sample >= reqHeight && halfW / sample >= reqWidth) sample *= 2
        return sample.coerceAtLeast(1)
    }

    private data class Holder(val image: ImageView, val badge: TextView, val check: CheckBox)
    private fun dp(v: View, n: Int) = (n * v.resources.displayMetrics.density).toInt()
}
