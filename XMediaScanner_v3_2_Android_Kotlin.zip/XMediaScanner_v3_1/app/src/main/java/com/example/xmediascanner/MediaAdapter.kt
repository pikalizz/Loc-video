package com.example.xmediascanner

import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors

class MediaAdapter(
    private val items: MutableList<MediaItem>,
    private val headers: (String) -> Map<String, String>,
    private val selectionChanged: () -> Unit
) : BaseAdapter() {
    private val pool = Executors.newFixedThreadPool(3)
    private val main = Handler(Looper.getMainLooper())

    override fun getCount() = items.size
    override fun getItem(position: Int) = items[position]
    override fun getItemId(position: Int) = position.toLong()

    override fun getView(position: Int, recycled: View?, parent: ViewGroup): View {
        val holder: Holder
        val root: LinearLayout
        if (recycled == null) {
            root = LinearLayout(parent.context).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(6, 6, 6, 6)
                background = GradientDrawable().apply {
                    setColor(0xFF202C40.toInt())
                    cornerRadius = 16f
                }
            }
            val frame = FrameLayout(parent.context)
            val image = ImageView(parent.context).apply {
                scaleType = ImageView.ScaleType.CENTER_CROP
                setBackgroundColor(0xFF111827.toInt())
            }
            frame.addView(image, FrameLayout.LayoutParams(-1, dp(parent, 118)))
            val badge = TextView(parent.context).apply {
                text = "▶ VIDEO"
                textSize = 10f
                setTextColor(Color.WHITE)
                setPadding(8, 4, 8, 4)
                background = GradientDrawable().apply { setColor(0xCC111827.toInt()); cornerRadius = 18f }
                visibility = View.GONE
            }
            frame.addView(badge, FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM or Gravity.START).apply {
                setMargins(6, 0, 0, 6)
            })
            val check = CheckBox(parent.context).apply {
                text = "Chọn"
                textSize = 12f
                setTextColor(Color.WHITE)
            }
            root.addView(frame)
            root.addView(check)
            holder = Holder(image, badge, check)
            root.tag = holder
        } else {
            root = recycled as LinearLayout
            holder = root.tag as Holder
        }

        val item = items[position]
        holder.check.setOnCheckedChangeListener(null)
        holder.check.isChecked = item.selected
        holder.check.setOnCheckedChangeListener { _, checked ->
            item.selected = checked
            selectionChanged()
        }
        holder.badge.visibility = if (item.isVideo) View.VISIBLE else View.GONE
        holder.image.tag = item.url
        holder.image.setImageDrawable(null)

        if (!item.isVideo) {
            pool.execute {
                try {
                    val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                    openImageConnection(item).use { stream -> BitmapFactory.decodeStream(stream, null, bounds) }
                    val sample = calculateSample(bounds.outWidth, bounds.outHeight, 600, 600)
                    val bitmapOptions = BitmapFactory.Options().apply { inSampleSize = sample }
                    val bmp = openImageConnection(item).use { stream -> BitmapFactory.decodeStream(stream, null, bitmapOptions) }
                    main.post {
                        if (holder.image.tag == item.url && bmp != null) holder.image.setImageBitmap(bmp)
                    }
                } catch (_: Exception) { }
            }
        } else {
            holder.image.setImageDrawable(GradientDrawable().apply {
                setColor(0xFF34445D.toInt()); cornerRadius = 12f
            })
        }

        root.setOnClickListener {
            item.selected = !item.selected
            notifyDataSetChanged()
            selectionChanged()
        }
        return root
    }

    private fun openImageConnection(item: MediaItem): java.io.InputStream {
        val conn = URL(item.url).openConnection() as HttpURLConnection
        headers(item.sourcePage).forEach { (k, v) -> conn.setRequestProperty(k, v) }
        conn.connectTimeout = 10000
        conn.readTimeout = 12000
        conn.instanceFollowRedirects = true
        if (conn.responseCode !in 200..299) {
            val code = conn.responseCode
            conn.disconnect()
            throw java.io.IOException("HTTP $code")
        }
        return object : java.io.FilterInputStream(conn.inputStream) {
            override fun close() {
                try { super.close() } finally { conn.disconnect() }
            }
        }
    }

    private fun calculateSample(width: Int, height: Int, reqWidth: Int, reqHeight: Int): Int {
        var sample = 1
        if (height > reqHeight || width > reqWidth) {
            var halfH = height / 2
            var halfW = width / 2
            while (halfH / sample >= reqHeight && halfW / sample >= reqWidth) sample *= 2
        }
        return sample.coerceAtLeast(1)
    }

    private data class Holder(val image: ImageView, val badge: TextView, val check: CheckBox)
    private fun dp(v: View, n: Int) = (n * v.resources.displayMetrics.density).toInt()
}
